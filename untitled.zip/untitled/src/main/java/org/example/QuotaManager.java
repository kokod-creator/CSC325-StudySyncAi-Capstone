package org.example;

import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Transaction;
import com.google.firebase.cloud.FirestoreClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

//This QuotaManager class implements a fixed-window rate l
// limiter designed to manage user access to resource-intensive features,
// such as AI generation, by tracking requests within a rolling 48-hour period
//Optimistic Concurrency: When checkAndIncrement is called, the transaction reads the user's
// current quota document, calculates the remaining window, and updates the count.

//make sure that it's api cost effective since

//Retry Logic: If another process modifies the same document simultaneously,
// Firestore automatically retries the transaction to prevent race conditions (e.g.,
// two requests incrementing the same counter at once).


public class QuotaManager {

    public static final int MAX_REQUESTS_PER_WINDOW = 10;
    private static final long WINDOW_DURATION_MS = 48L * 60 * 60 * 1000; // 48 hours

    private final Firestore db;
    private final String userId;

    // -------------------------------------------------------------------------
    // Interfaces
    // -------------------------------------------------------------------------

    public interface QuotaCallback {
        void onResult(boolean allowed, int usedCount, int maxCount);
        void onError(Exception e);
    }

    public interface TimeCallback {
        void onResult(long millisRemaining);
    }

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /**
     * @param userId The current logged-in user's ID
     */
    public QuotaManager(String userId) {
        this.db = FirestoreClient.getFirestore();
        this.userId = userId;
    }

    // -------------------------------------------------------------------------
    // checkAndIncrement
    // -------------------------------------------------------------------------

    /**
     * Checks quota and increments atomically if allowed.
     * Runs on a background thread — safe to call from JavaFX event handlers.
     *
     * Call BEFORE every AI generation (summary generate, regen, or quiz).
     */
    public void checkAndIncrement(QuotaCallback callback) {
        new Thread(() -> {
            try {
                DocumentReference quotaRef = db
                        .collection("users")
                        .document(userId)
                        .collection("quota")
                        .document("current");

                Long result = db.runTransaction(
                        (Transaction.Function<Long>) transaction -> {

                            DocumentSnapshot snapshot = transaction.get(quotaRef).get();
                            long now = System.currentTimeMillis();

                            long windowStart = 0;
                            int usageCount = 0;

                            if (snapshot.exists()) {
                                Long storedStart = snapshot.getLong("windowStart");
                                Long storedUsage = snapshot.getLong("usageCount");
                                windowStart = storedStart != null ? storedStart : 0;
                                usageCount = storedUsage != null ? storedUsage.intValue() : 0;
                            }

                            // Reset if 48-hour window has expired
                            if (now - windowStart >= WINDOW_DURATION_MS) {
                                windowStart = now;
                                usageCount = 0;
                            }

                            if (usageCount >= MAX_REQUESTS_PER_WINDOW) {
                                // Quota exceeded — return negative as signal, do not write
                                return (long) -usageCount;
                            }

                            // Increment and persist
                            usageCount++;
                            Map<String, Object> data = new HashMap<>();
                            data.put("usageCount", usageCount);
                            data.put("windowStart", windowStart);
                            transaction.set(quotaRef, data);

                            return (long) usageCount; // positive = allowed

                        }).get(); // blocks background thread until Firestore responds

                int resultInt = result.intValue();
                if (resultInt <= 0) {
                    callback.onResult(false, -resultInt, MAX_REQUESTS_PER_WINDOW);
                } else {
                    callback.onResult(true, resultInt, MAX_REQUESTS_PER_WINDOW);
                }

            } catch (InterruptedException | ExecutionException e) {
                callback.onError(e);
            }
        }).start();
    }

    // -------------------------------------------------------------------------
    // getQuotaStatus
    // -------------------------------------------------------------------------

    /**
     * Reads current quota state WITHOUT incrementing.
     * Use to display "3 / 10 uses remaining" in the UI on screen load.
     */
    public void getQuotaStatus(QuotaCallback callback) {
        new Thread(() -> {
            try {
                DocumentReference quotaRef = db
                        .collection("users")
                        .document(userId)
                        .collection("quota")
                        .document("current");

                DocumentSnapshot snapshot = quotaRef.get().get();
                long now = System.currentTimeMillis();

                if (!snapshot.exists()) {
                    callback.onResult(true, 0, MAX_REQUESTS_PER_WINDOW);
                    return;
                }

                Long windowStart = snapshot.getLong("windowStart");
                Long usageCount = snapshot.getLong("usageCount");

                long ws = windowStart != null ? windowStart : 0;
                int uc = usageCount != null ? usageCount.intValue() : 0;

                // If window expired, locally treat as reset (Firestore resets on next write)
                if (now - ws >= WINDOW_DURATION_MS) {
                    uc = 0;
                }

                callback.onResult(uc < MAX_REQUESTS_PER_WINDOW, uc, MAX_REQUESTS_PER_WINDOW);

            } catch (InterruptedException | ExecutionException e) {
                callback.onError(e);
            }
        }).start();
    }

    // -------------------------------------------------------------------------
    // getTimeUntilReset
    // -------------------------------------------------------------------------

    /**
     * Returns milliseconds remaining in the current 48-hour window.
     * Use to show "Resets in 12h 30m" when quota is exceeded.
     */
    public void getTimeUntilReset(TimeCallback callback) {
        new Thread(() -> {
            try {
                DocumentReference quotaRef = db
                        .collection("users")
                        .document(userId)
                        .collection("quota")
                        .document("current");

                DocumentSnapshot snapshot = quotaRef.get().get();

                if (!snapshot.exists()) {
                    callback.onResult(0);
                    return;
                }

                Long windowStart = snapshot.getLong("windowStart");
                if (windowStart == null) {
                    callback.onResult(0);
                    return;
                }

                long elapsed = System.currentTimeMillis() - windowStart;
                long remaining = WINDOW_DURATION_MS - elapsed;
                callback.onResult(Math.max(0, remaining));

            } catch (InterruptedException | ExecutionException e) {
                callback.onResult(0);
            }
        }).start();
    }
}