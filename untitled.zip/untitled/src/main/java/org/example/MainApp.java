package org.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) {

        // SIMPLE TEST UI (just to confirm everything works)
        Label label = new Label("Your Study AI App is running 🚀");

        Scene scene = new Scene(label, 600, 400);

        stage.setTitle("Study AI Tool");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
