package org.example;

import javafx.application.Platform;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextArea;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class StudyController {

    // ---- FXML bindings ----
    @FXML private TextArea summaryArea;
    @FXML private Button regenerateBtn;
    @FXML private TextArea quizArea;
    @FXML private Button generateQuizBtn;
    @FXML private Button shuffleQuizBtn;
    @FXML private Label quotaLabel;
    @FXML private Label statusLabel;
    @FXML private ProgressIndicator loadingIndicator;

    // ---- Managers ----
    private SummaryManager summaryManager;
    private QuizManager quizManager;
    private QuotaManager quotaManager;

    // ---- State ----
    // In production, pull these from your navigation/session state
    private static final String TOPIC_ID = "topic_001";
    private static final String TOPIC_TEXT =
            "The mitochondria is the powerhouse of the cell. " +
                    "It generates ATP through oxidative phosphorylation...";
    private final String currentUserId = "user_123"; // Replace with your auth user ID

    // -------------------------------------------------------------------------
    // Initialization — called automatically by JavaFX after FXML is loaded
    // -------------------------------------------------------------------------

    @FXML
    public void initialize() {
        summaryManager = new SummaryManager(currentUserId);
        quizManager    = new QuizManager(currentUserId);
        quotaManager   = new QuotaManager(currentUserId);

        // Shuffle button is hidden until a quiz is generated
        shuffleQuizBtn.setVisible(false);
        shuffleQuizBtn.setManaged(false);

        loadExistingSummary();
        refreshQuotaDisplay();
    }

    // -------------------------------------------------------------------------
    // Summary: Load on startup, auto-regen if bad
    // -------------------------------------------------------------------------

    private void loadExistingSummary() {
        setLoading(true);
        summaryManager.loadSummary(TOPIC_ID, new SummaryManager.SummaryLoadCallback() {
            @Override
            public void onLoaded(String summaryText, boolean isBadSummary) {
                if (isBadSummary) {
                    // Auto-generate since summary is missing or invalid
                    Platform.runLater(() -> summaryArea.setText("Generating summary..."));
                    autoGenerateSummary();
                } else {
                    Platform.runLater(() -> {
                        setLoading(false);
                        summaryArea.setText(summaryText);
                        regenerateBtn.setDisable(false);
                    });
                }
            }

            @Override
            public void onError(Exception e) {
                Platform.runLater(() -> {
                    setLoading(false);
                    summaryArea.setText("Could not load summary.");
                    setStatus("Error loading summary: " + e.getMessage());
                });
            }
        });
    }

    private void autoGenerateSummary() {
        summaryManager.generateSummary(TOPIC_ID, TOPIC_TEXT, new SummaryManager.SummaryCallback() {
            @Override
            public void onSuccess(String summaryText) {
                Platform.runLater(() -> {
                    setLoading(false);
                    summaryArea.setText(summaryText);
                    regenerateBtn.setDisable(false);
                    refreshQuotaDisplay();
                });
            }

            @Override
            public void onQuotaExceeded(int usedCount, int maxCount) {
                Platform.runLater(() -> {
                    setLoading(false);
                    summaryArea.setText("Summary unavailable — quota reached.");
                    regenerateBtn.setDisable(true);
                    showQuotaExceededStatus();
                });
            }

            @Override
            public void onError(Exception e) {
                Platform.runLater(() -> {
                    setLoading(false);
                    summaryArea.setText("Failed to generate summary.");
                    setStatus("Error: " + e.getMessage());
                });
            }
        });
    }

    // -------------------------------------------------------------------------
    // Regenerate Summary Button
    // -------------------------------------------------------------------------

    @FXML
    private void onRegenerateClicked() {
        setLoading(true);
        setStatus("Regenerating summary...");

        summaryManager.regenerateSummary(TOPIC_ID, TOPIC_TEXT, new SummaryManager.SummaryCallback() {
            @Override
            public void onSuccess(String summaryText) {
                Platform.runLater(() -> {
                    setLoading(false);
                    summaryArea.setText(summaryText);
                    setStatus("Summary regenerated successfully.");
                    refreshQuotaDisplay();
                });
            }

            @Override
            public void onQuotaExceeded(int usedCount, int maxCount) {
                Platform.runLater(() -> {
                    setLoading(false);
                    showQuotaExceededStatus();
                });
            }

            @Override
            public void onError(Exception e) {
                Platform.runLater(() -> {
                    setLoading(false);
                    setStatus("Regeneration failed. Please try again.");
                });
            }
        });
    }

    // -------------------------------------------------------------------------
    // Generate Quiz Button
    // -------------------------------------------------------------------------

    @FXML
    private void onGenerateQuizClicked() {
        setLoading(true);
        setStatus("Generating quiz...");

        quizManager.generateQuiz(TOPIC_TEXT, new QuizManager.QuizCallback() {
            @Override
            public void onSuccess(List<QuizManager.QuizQuestion> questions, int shufflesRemaining) {
                Platform.runLater(() -> {
                    setLoading(false);
                    displayQuiz(questions);
                    showShuffleButton(shufflesRemaining);
                    setStatus("Quiz generated!");
                    refreshQuotaDisplay();
                });
            }

            @Override
            public void onQuotaExceeded(int usedCount, int maxCount) {
                Platform.runLater(() -> {
                    setLoading(false);
                    showQuotaExceededStatus();
                });
            }

            @Override
            public void onError(Exception e) {
                Platform.runLater(() -> {
                    setLoading(false);
                    setStatus("Failed to generate quiz. Please try again.");
                });
            }
        });
    }

    // -------------------------------------------------------------------------
    // Shuffle Quiz Button
    // -------------------------------------------------------------------------

    @FXML
    private void onShuffleQuizClicked() {
        quizManager.shuffleQuiz(new QuizManager.ShuffleCallback() {
            @Override
            public void onShuffled(List<QuizManager.QuizQuestion> shuffledQuestions,
                                   int shufflesRemaining) {
                Platform.runLater(() -> {
                    displayQuiz(shuffledQuestions);
                    updateShuffleButton(shufflesRemaining);
                    String msg = shufflesRemaining == 0
                            ? "Quiz shuffled! No more shuffles available."
                            : "Quiz shuffled! " + shufflesRemaining + " shuffle(s) left.";
                    setStatus(msg);
                });
            }

            @Override
            public void onMaxShufflesReached() {
                Platform.runLater(() -> {
                    hideShuffleButton();
                    setStatus("Maximum shuffles reached (3).");
                });
            }
        });
    }

    // -------------------------------------------------------------------------
    // UI Helpers
    // -------------------------------------------------------------------------

    /** Renders quiz questions into the TextArea. Replace with a ListView/TableView in production. */
    private void displayQuiz(List<QuizManager.QuizQuestion> questions) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < questions.size(); i++) {
            QuizManager.QuizQuestion q = questions.get(i);
            sb.append(i + 1).append(". ").append(q.question).append("\n");
            for (String opt : q.options) {
                sb.append("   ").append(opt).append("\n");
            }
            sb.append("\n");
        }
        quizArea.setText(sb.toString());
    }

    private void showShuffleButton(int shufflesRemaining) {
        shuffleQuizBtn.setVisible(true);
        shuffleQuizBtn.setManaged(true);
        updateShuffleButton(shufflesRemaining);
    }

    private void updateShuffleButton(int shufflesRemaining) {
        if (shufflesRemaining <= 0) {
            hideShuffleButton();
        } else {
            shuffleQuizBtn.setVisible(true);
            shuffleQuizBtn.setManaged(true);
            shuffleQuizBtn.setText("Shuffle Quiz (" + shufflesRemaining + " left)");
        }
    }

    private void hideShuffleButton() {
        shuffleQuizBtn.setVisible(false);
        shuffleQuizBtn.setManaged(false);
    }

    private void refreshQuotaDisplay() {
        quotaManager.getQuotaStatus(new QuotaManager.QuotaCallback() {
            @Override
            public void onResult(boolean allowed, int usedCount, int maxCount) {
                Platform.runLater(() ->
                        quotaLabel.setText("Uses: " + usedCount + " / " + maxCount));
            }

            @Override
            public void onError(Exception e) {
                // Silently fail — quota display is non-critical
            }
        });
    }

    private void showQuotaExceededStatus() {
        quotaManager.getTimeUntilReset(millisRemaining -> {
            long hours = TimeUnit.MILLISECONDS.toHours(millisRemaining);
            long minutes = TimeUnit.MILLISECONDS.toMinutes(millisRemaining) % 60;
            Platform.runLater(() ->
                    setStatus("Quota reached. Resets in " + hours + "h " + minutes + "m."));
        });
    }

    private void setLoading(boolean loading) {
        loadingIndicator.setVisible(loading);
        regenerateBtn.setDisable(loading);
        generateQuizBtn.setDisable(loading);
    }

    private void setStatus(String message) {
        statusLabel.setText(message);
    }
}