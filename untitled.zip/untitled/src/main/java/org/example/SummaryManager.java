package org.example;

import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

//Purpose: To generate and manage AI-powered summaries of study
// content for users in a scalable manner.

//Key Functionalities:
//Generate Summary: Creates a new summary upon request.
//Load Summary: Fetches existing summaries from the cache.
//Regenerate Summary: Allows users to refresh a summary, maintaining a count of retries.
//Bad Summary Detection: Ensures quality by validating summary length and content.
//3. Data Flow & Interaction (How it Works)
//Request: User clicks "Summarize."
//Quota Check: QuotaManager verifies if the user has remaining usage.
//API Call: callAiApi asynchronously generates the summary.
//Storage: saveSummary persists the summaryText, topicId, and regenCount to Firestore.
//Response: The summary is returned to the user via the SummaryCallback.
//4. Key Design Decisions (Trade-offs)
//Asynchronous Processing: Used new Thread() to ensure UI responsiveness during DB reads/writes.
//Fire-and-forget Write: Using .set(data) without .get() makes saving faster,
// though it sacrifices immediate verification of success.

//Offline/Cache Support: loadSummary first checks Firestore to minimize API costs.
//Quality Threshold: The isSummaryBad function rejects very short summaries, ensuring
// high user experience.

public class SummaryManager {

    // Summaries shorter than this are considered bad/incomplete
    private static final int MIN_SUMMARY_LENGTH = 50;

    private final Firestore db;
    private final String userId;
    private final QuotaManager quotaManager;

    // -------------------------------------------------------------------------
    // Interfaces
    // -------------------------------------------------------------------------

    public interface SummaryCallback {
        void onSuccess(String summaryText);
        void onQuotaExceeded(int usedCount, int maxCount);
        void onError(Exception e);
    }

    public interface SummaryLoadCallback {
        void onLoaded(String summaryText, boolean isBadSummary);
        void onError(Exception e);
    }

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    public SummaryManager(String userId) {
        this.db = FirestoreClient.getFirestore();
        this.userId = userId;
        this.quotaManager = new QuotaManager(userId);
    }

    // -------------------------------------------------------------------------
    // 1. Generate (first time)
    // -------------------------------------------------------------------------

    /**
     * Generates a summary for the given topic. Counts as 1 quota usage.
     *
     * @param topicId   Unique ID for this topic (e.g. a UUID or Firestore doc ID)
     * @param topicText The raw study content to summarize
     */
    public void generateSummary(String topicId, String topicText, SummaryCallback callback) {
        quotaManager.checkAndIncrement(new QuotaManager.QuotaCallback() {
            @Override
            public void onResult(boolean allowed, int usedCount, int maxCount) {
                if (!allowed) {
                    callback.onQuotaExceeded(usedCount, maxCount);
                    return;
                }
                callAiApi(topicText, summaryText -> {
                    saveSummary(topicId, topicText, summaryText, 0);
                    callback.onSuccess(summaryText);
                }, callback::onError);
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    // -------------------------------------------------------------------------
    // 2. Load existing summary + bad-summary detection
    // -------------------------------------------------------------------------


    public void loadSummary(String topicId, SummaryLoadCallback callback) {
        new Thread(() -> {
            try {
                DocumentSnapshot snapshot = db
                        .collection("users")
                        .document(userId)
                        .collection("summaries")
                        .document(topicId)
                        .get()
                        .get();

                if (!snapshot.exists()) {
                    callback.onLoaded(null, true); // No summary yet
                    return;
                }

                String summaryText = snapshot.getString("summaryText");
                callback.onLoaded(summaryText, isSummaryBad(summaryText));

            } catch (InterruptedException | ExecutionException e) {
                callback.onError(e);
            }
        }).start();
    }

    // -------------------------------------------------------------------------
    // 3. Regenerate (button click or auto-trigger)
    // -------------------------------------------------------------------------


    public void regenerateSummary(String topicId, String topicText, SummaryCallback callback) {
        quotaManager.checkAndIncrement(new QuotaManager.QuotaCallback() {
            @Override
            public void onResult(boolean allowed, int usedCount, int maxCount) {
                if (!allowed) {
                    callback.onQuotaExceeded(usedCount, maxCount);
                    return;
                }

                // Read current regenCount before writing
                new Thread(() -> {
                    try {
                        DocumentSnapshot snapshot = db
                                .collection("users")
                                .document(userId)
                                .collection("summaries")
                                .document(topicId)
                                .get()
                                .get();

                        int currentRegen = 0;
                        if (snapshot.exists()) {
                            Long stored = snapshot.getLong("regenCount");
                            currentRegen = stored != null ? stored.intValue() : 0;
                        }

                        final int newRegenCount = currentRegen + 1;

                        callAiApi(topicText, summaryText -> {
                            saveSummary(topicId, topicText, summaryText, newRegenCount);
                            callback.onSuccess(summaryText);
                        }, callback::onError);

                    } catch (InterruptedException | ExecutionException e) {
                        callback.onError(e);
                    }
                }).start();
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    // -------------------------------------------------------------------------
    // 4. Bad summary detection
    // -------------------------------------------------------------------------


    public boolean isSummaryBad(String summaryText) {
        if (summaryText == null || summaryText.trim().isEmpty()) return true;
        if (summaryText.trim().length() < MIN_SUMMARY_LENGTH) return true;
        // Catch error-string responses from the AI
        if (summaryText.toLowerCase().contains("error") && summaryText.trim().length() < 100) return true;
        return false;
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private void saveSummary(String topicId, String topicText,
                             String summaryText, int regenCount) {
        Map<String, Object> data = new HashMap<>();
        data.put("topicId", topicId);
        data.put("topicText", topicText);
        data.put("summaryText", summaryText);
        data.put("generatedAt", System.currentTimeMillis());
        data.put("regenCount", regenCount);

        db.collection("users")
                .document(userId)
                .collection("summaries")
                .document(topicId)
                .set(data);
        // Fire-and-forget write — add .get() if you need to confirm success
    }


    private void callAiApi(String topicText,
                           AiSuccessCallback onSuccess,
                           AiErrorCallback onError) {
        // TODO: Replace with your team's actual AI API call.
        // Example with Java HttpClient (Java 11+):
        //
        // HttpClient client = HttpClient.newHttpClient();
        // HttpRequest request = HttpRequest.newBuilder()
        //     .uri(URI.create("https://api.openai.com/v1/..."))
        //     .header("Authorization", "Bearer " + API_KEY)
        //     .POST(HttpRequest.BodyPublishers.ofString(buildPrompt(topicText)))
        //     .build();
        // HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        // onSuccess.onResult(parseResponse(response.body()));

        // Placeholder — remove when integrating:
        onSuccess.onResult("Placeholder summary for: " +
                topicText.substring(0, Math.min(30, topicText.length())) + "...");
    }

    private interface AiSuccessCallback {
        void onResult(String summaryText);
    }

    private interface AiErrorCallback {
        void onError(Exception e);
    }
}